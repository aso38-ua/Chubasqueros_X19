﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Library;
using library;

namespace Interfaz
{
    public partial class InterfazPedido : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ENUsuario usuario = new ENUsuario();
            usuario.nombre = (string)Session["username"];
            usuario.readUsuario();
            if (usuario.esAdmin) { Response.Redirect(""); }
            else
            {

                String constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
                String consultaString = "SELECT * FROM [dbo].[pedido] WHERE usuario_id = '" + usuario.id + "';";
                SqlConnection conexion = new SqlConnection(constring);
                conexion.Open();
                ENProducto[] prod = new ENProducto[1];
                try
                {

                    SqlCommand consulta = new SqlCommand(consultaString, conexion);
                    SqlDataReader consultabusqueda = consulta.ExecuteReader();
                    int contador = 0;
                    while (consultabusqueda.Read())
                    {
                        contador++;
                    }
                    prod = new ENProducto[contador];
                    contador = 0;
                    consultabusqueda.Close();
                    consultabusqueda = consulta.ExecuteReader();
                    while (consultabusqueda.Read())
                    {
                        prod[contador] = new ENProducto();
                        prod[contador].setCodigo(int.Parse(consultabusqueda["producto_id"].ToString()));
                        prod[contador].readProducto();
                        prod[contador].cantidad = int.Parse(consultabusqueda["cantidad"].ToString());
                        prod[contador].ptotal = float.Parse(consultabusqueda["preciotot"].ToString());
                        prod[contador].fecha = consultabusqueda["fechaaprox"].ToString();
                        contador++;
                    }
                    consultabusqueda.Close();
                    if (contador == 0) prod = null;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Order operation has failed. Error: {0} ", ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Order operation has failed. Error: {0} ", ex.Message);
                }
                finally
                {
                    conexion.Close();
                }
                //Contenedor del producto (uso de ListView)
                ListView_Pedido.DataSource = prod;
                ListView_Pedido.DataBind();

                //Contenedor del ususario (uso de ListView)

                ListView_PedUsuario.DataSource = new List<ENUsuario> { usuario };
                ListView_PedUsuario.DataBind();

            }

        }

        protected void btn_pagar(object sender, EventArgs e)
        {

            ENUsuario usuario = new ENUsuario();
            ENProducto producto = new ENProducto();
            ENPedido pedido = new ENPedido(producto.getCodigo(), usuario.id);
            String cons = ConfigurationManager.ConnectionStrings["Database"].ToString();
            SqlConnection conectsql = null;
            conectsql = new SqlConnection(cons);
            conectsql.Open();
            string cout = "INSERT INTO pedido (producto_id, preciotot, cantidad) VALUES (@producto_id, @preciotot, @cantidad) WHERE usuario_id = " + usuario.id + ";";

            using (SqlCommand command = new SqlCommand(cout, conectsql))
            {
                command.Parameters.AddWithValue("@producto_id", pedido.producto);
                command.Parameters.AddWithValue("@preciotot", pedido.total);
                command.Parameters.AddWithValue("@cantidad", pedido.cantidad);
                command.ExecuteNonQuery();
            }
            //Llevaria a otra interfaz de pagar
            Response.Redirect("");
            //Response.Redirect("InterfazPedido.aspx");
        }

        protected void btn_cancelar(object sender, EventArgs e)
        {
            bool existe = false;
            ENUsuario usuario = new ENUsuario();
            usuario.nombre = (string)Session["username"];
            usuario.readUsuario();
            String constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();

                string query = "DELETE * FROM [dbo].[pedido] WHERE usuario_id = '" + usuario.id + "';";
                existe = true;
                SqlCommand consulta = new SqlCommand(query, connection);

                connection.Close();
            }
            catch (SqlException ex)
            {
                existe = false;
                Console.WriteLine("Product operation has failed.Error: {0}", ex.Message);
            }
            catch (Exception ex)
            {
                existe = false;
                Console.WriteLine("Product operation has failed.Error: {0}", ex.Message);
            }
            finally
            {
                connection.Close();
                if (!existe) Message.Text = "No se ha podido cancelar el pedido";
                else Response.Redirect("InterfazCarrito.aspx");
            }
        }
        protected string ObtenerPrecioTotal()
        {
            float total = 0;
            ENUsuario usuario = new ENUsuario();
            usuario.nombre = (string)Session["username"];
            usuario.readUsuario();
            String cons = ConfigurationManager.ConnectionStrings["Database"].ToString();
            SqlConnection conectsql = null;
            try
            {
                conectsql = new SqlConnection(cons);
                conectsql.Open();
                //string cout = "INSERT INTO carrito (producto_id, preciotot, cantidad) VALUES (@producto_id, @preciotot, @cantidad)";
                string cout = "SELECT preciotot, cantidad from [dbo].[pedido] where usuario_id ='" + usuario.id + "';";
                SqlCommand command = new SqlCommand(cout, conectsql);
                SqlDataReader search = command.ExecuteReader();
                search.Read();
                ENCarrito carrito = new ENCarrito(usuario.id);
                carrito.verCarrito();
                if (carrito.producto != null)
                {
                    int cantidadcarro = carrito.producto.Length;
                    ENProducto[] prod = new ENProducto[cantidadcarro];
                    for (int i = 0; i < cantidadcarro; i++)
                    {
                        total += prod[i].getPrecio();
                    }
                    carrito.total = total;
                }
                search.Close();

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Product operation has failed.Error: {0}", ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Product operation has failed.Error: {0}", ex.Message);
            }
            conectsql.Close();
            return total.ToString("C");
        }
    }
}