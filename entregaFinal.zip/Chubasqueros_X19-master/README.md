# Chubasqueros para peces
Miembros:<br>
Alberto Sáez Orts-48793033M <b>(Coordinador)</b><br>
Javier Sánchez Felipe-23902032H<br>
Fátima María Pelegrín Pelegrín-20930178V<br>
María Jover Espí-53977393G<br>
María Yaru Puche Sanchiz-46083607W<br>
Cristopher Soto Martínez-53247376F<br>
Joan Catasús Quesada-77853871K<br>
## Descripcion
El proyecto consistirá en una tienda de animales enfocada a la venta de accesorios para estos, especialmente para los peces y demás habitantes de mares, ríos océanos y sobretodo, peceras; únicamente los usuarios registrados podrán comprar en la web, a pesar de no poder comprar
el usuario no registrado podrá acceder a la página sin problema y poder seguir navegando, pero sin contar con una serie de ventajas con las que contarán los registrados. Además de contar con una jerarquía dentro de este
proyecto para controlar quien tiene un acceso especial; la jerarquía consta de usuario, registrado y administrador.
## Parte pública
Ver los accesorios.<br>
Opción de registro y así poder acceder a la parte privada.<br>
Ver los comentarios de los productos.<br>
Ver las ofertas que hay de un determinado producto.<br>
Si un usuario está registrado y quiere acceder a su cuenta, poder entrar a la misma a través de un login.<br>
Acceso al carrito de la compra.<br>
Leer el foro con los mensajes de los usuarios.<br>

## Listado EN Público
ENProducto, se guardará la información necesaria para mostrar los accesorios.<br>
ENRegistro, necesario para poder registrar a los usuarios que quieran acceder a la parte privada.<br>
ENOferta, se mostrará si hay alguna oferta de un producto y cual es la determinada oferta.<br>
ENComentario, se mostrarán los comentarios del producto seleccionado.<br>
ENLogin, si el usuario ya está registrado podrá acceder a su cuenta a través de un formulario de registro.<br>
ENCarrito, el usuario podrá añadir productos al carrito.<br>
ENForo, se podrán ver comentarios de la gente en un foro de la web.<br>

## Parte privada
Comprar los productos.<br>
Modificar su perfil de usuario.<br>
Escribir comentarios de productos.<br>
Tener una lista de favoritos.<br>
Poder reservar productos.<br>
Se podrán añadir comentarios al foro una vez el usuario esté registrado o loggeado.<br>
El usuario podrá eliminar su cuenta de usuario.<br>
Ver historial de compras.<br>
Añadir producto (solo administrador).

## Listado EN Privado
ENPerfil, el usuario será capaz de actualizar su perfil.<br>
EnReserva, se podrá reservar artículos que no están disponibles todavía.<br>
ENFavoritos, se podrán añadir los productos favoritos del usuario en una lista.<br>
ENForo, se podrán añadir mensajes al foro.<br>
ENAdministrador, información del administrador del proyecto web.<br>
ENComentario, se podrán escribir comentarios de un determinado producto.

## Posibles mejoras
Doble verificación en el login.<br>
Cambio de idioma.<br>
Mostrar una imagen/vídeo de carga en la web.<br>
Buscador en la web.<br>
Enlaces a redes sociales.<br>
Aviso de epilepsia.<br>
Filtro modo noche.

## Tareas hechas cad uno (Valoración individual)
![Tareas](Tareas.PNG)
